<?php
// web/scripts/php_backup.php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';

$backupFile = __DIR__ . '/../full_backup.sql';
$output = "-- SnipTools MySQL Backup\n-- Generated " . date('Y-m-d H:i:s') . "\n\n";

echo "Backing up to: $backupFile\n";

// Get Tables
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

foreach ($tables as $table) {
    echo "Processing table: $table\n";
    $output .= "DROP TABLE IF EXISTS `$table`;\n";

    // Create Table
    $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
    $output .= $create['Create Table'] . ";\n\n";

    // Insert Data
    $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        $keys = array_keys($row);
        $keys = array_map(function ($k) {
            return "`$k`"; }, $keys);

        $values = array_values($row);
        $values = array_map(function ($v) use ($pdo) {
            return $v === null ? "NULL" : $pdo->quote($v);
        }, $values);

        $output .= "INSERT INTO `$table` (" . implode(", ", $keys) . ") VALUES (" . implode(", ", $values) . ");\n";
    }
    $output .= "\n";
}

file_put_contents($backupFile, $output);
echo "SUCCESS: Backup created at web/full_backup.sql\n";
